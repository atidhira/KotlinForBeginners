package com.dicoding.kotlinforbeginners

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView


class HomeActivity : AppCompatActivity() {

    private lateinit var rvHome: RecyclerView
    private var list: ArrayList<HomeData> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvHome = findViewById(R.id.rv_home_item)
        rvHome.setHasFixedSize(true)

        list.addAll(HomeObjectData.listData)
        showRecyclerList(list)
    }

    private fun showRecyclerList( list: ArrayList<HomeData>){
        rvHome.layoutManager = LinearLayoutManager(this)
        val listHomeAdapter = HomeDataAdapter(list,this)
        rvHome.adapter = listHomeAdapter
    }
}